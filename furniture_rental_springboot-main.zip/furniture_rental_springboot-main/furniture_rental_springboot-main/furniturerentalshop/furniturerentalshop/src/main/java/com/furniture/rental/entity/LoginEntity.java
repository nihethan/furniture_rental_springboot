package com.furniture.rental.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;


@Entity
@Table(name="customerlogin")
@Data
public class LoginEntity {
	@Id
	@Column(name="username")
	private String userName;
	
	@Column(name="password")
	private String password;
	
	
	

}
	

