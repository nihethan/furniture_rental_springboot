package com.furniture.rental.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.furniture.rental.dto.CustomerLoginDto;
import com.furniture.rental.dto.ResponseDto;
import com.furniture.rental.service.LoginService;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("api")
@Data
@RequiredArgsConstructor
public class LoginController {
 
    private final LoginService loginService;
    
    @PostMapping("/login")
    public ResponseEntity<ResponseDto> createLoginDetails(@RequestBody CustomerLoginDto customerDto){
        return ResponseEntity.ok(loginService.createLoginDetails(customerDto));
    }
    
    @GetMapping("/login")
    public ResponseEntity<List<CustomerLoginDto>> getLoginDetails(){
    	return ResponseEntity.ok(loginService.getLoginDetails());
    }
    
    @DeleteMapping("/login")
    public ResponseEntity<ResponseDto> deleteLoginData(@RequestParam("userName") String userName){
    	return ResponseEntity.ok(loginService.deleteLoginData(userName));
    }
    
    @GetMapping("/loginn")
    public ResponseEntity<CustomerLoginDto> getCustomerDetailsById(String userName){
    	return ResponseEntity.ok(loginService.getCustomerDetailsById(userName));
    }
    
    
}
