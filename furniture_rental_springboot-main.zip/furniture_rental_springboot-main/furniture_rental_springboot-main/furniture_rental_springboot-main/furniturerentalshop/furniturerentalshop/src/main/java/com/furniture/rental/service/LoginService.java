package com.furniture.rental.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.furniture.rental.dto.CustomerLoginDto;
import com.furniture.rental.dto.ResponseDto;

public interface LoginService {

	ResponseDto createLoginDetails(CustomerLoginDto customerDto);

	List<CustomerLoginDto> getLoginDetails();

	ResponseDto deleteLoginData(String userName);

	CustomerLoginDto getCustomerDetailsById(String userName);

	//CustomerLoginDto getCustomerDetailById(String userName);

	//CustomerLoginDto getCustomerDetailsById(String userName);

	//CustomerLoginDto getCustomerDetailById(String userName);


}
