package com.furniture.rental.service;


import org.springframework.stereotype.Service;

import com.furniture.rental.dto.AddtoCartDto;
import com.furniture.rental.dto.ResponseDto;

@Service
public interface AddtoCartService {

    ResponseDto createAddtoCartDetails(AddtoCartDto addtocartdto);

	AddtoCartDto getAddtoCartItemsDetails();

}
