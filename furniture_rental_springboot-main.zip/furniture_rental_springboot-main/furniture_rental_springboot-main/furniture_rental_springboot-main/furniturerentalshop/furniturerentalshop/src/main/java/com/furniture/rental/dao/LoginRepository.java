package com.furniture.rental.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.furniture.rental.entity.LoginEntity;

@Repository
public interface LoginRepository extends JpaRepository<LoginEntity,String>{
   
//	@Query(nativeQuery = true, value = "SELECT * FROM student WHERE branch = :branch AND age = :age")
//	List<Entity> getDetails(@Param("") String branch, @Param("age") int age);)
}
