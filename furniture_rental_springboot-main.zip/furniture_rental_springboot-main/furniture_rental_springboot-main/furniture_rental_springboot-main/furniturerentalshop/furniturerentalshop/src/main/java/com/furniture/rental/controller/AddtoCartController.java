package com.furniture.rental.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.furniture.rental.dto.AddtoCartDto;
import com.furniture.rental.dto.CustomerLoginDto;
import com.furniture.rental.dto.ResponseDto;
import com.furniture.rental.service.AddtoCartService;

import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("api")
@RequiredArgsConstructor
public class AddtoCartController {
	
private final AddtoCartService addtocartservice;

@PostMapping("/addtocart")
public ResponseEntity<ResponseDto> createAddtoCartDetails(@RequestBody AddtoCartDto addtocartdto){
			return ResponseEntity.ok(addtocartservice.createAddtoCartDetails(addtocartdto));
         }  
//@GetMapping("/addtocart")
//public ResponseEntity<List<CustomerLoginDto>> getAddtoCartItemsDetails(){
//     return ResponseEntity.ok(addtocartservice.getAddtoCartItemsDetails());
//         }

}
