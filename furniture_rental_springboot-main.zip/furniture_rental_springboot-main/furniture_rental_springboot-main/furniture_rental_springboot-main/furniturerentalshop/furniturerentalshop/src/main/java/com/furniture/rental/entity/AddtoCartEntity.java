package com.furniture.rental.entity;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="furnitureitems")
@Data
public class AddtoCartEntity {
	@Id
	@UuidGenerator
	@Column(name="furniture_id")
	private String furnitureId;
    
	@Column(name="furniture_name")
	private String furnitureName;
	
	@Column(name="furniture_material_type")
	private String furnitureMaterialType;
	
	@Column(name="furniture_count")
	private int furnitureCount;
	
     
}
