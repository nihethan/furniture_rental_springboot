package com.furniture.rental.serviceimpl;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.furniture.rental.dao.AddtoCartRepository;
import com.furniture.rental.dto.AddtoCartDto;
import com.furniture.rental.dto.ResponseDto;
import com.furniture.rental.entity.AddtoCartEntity;
import com.furniture.rental.service.AddtoCartService;

import lombok.Data;

@Service
@Data
public class AddtoCartServiceImpl implements AddtoCartService {
private final AddtoCartRepository addtoCartRepository;
	
	@Override
	public ResponseDto createAddtoCartDetails(AddtoCartDto addtocartdto) {
		// TODO Auto-generated method stub
		ResponseDto responsedto=new ResponseDto();
		try {
			AddtoCartEntity addtocart=new AddtoCartEntity();
			
			if(addtocartdto.getFurnitureId()!=null && addtocartdto.getFurnitureCount()>0) {
				Optional<AddtoCartEntity> addtocartoption=addtoCartRepository.findById(addtocartdto.getFurnitureId());
				if(addtocartoption.isPresent()) {
//					addtocart.setFurnitureCount(addtocartdto.getFurnitureCount());
					addtocart=addtocartoption.get();
					addtocart.setFurnitureName(addtocartdto.getFurnitureName());
					addtocart.setFurnitureMaterialType(addtocartdto.getFurnitureMaterialType());
					addtocart.setFurnitureCount(addtocartdto.getFurnitureCount());
					addtoCartRepository.save(addtocart);
					responsedto.setMessage("Updated Successfully");
					responsedto.setStatus(200);
					return responsedto;
					
				}
			}
			else if(addtocartdto.getFurnitureCount()>0 && addtocartdto.getFurnitureId()==null) {
				addtocart.setFurnitureName(addtocartdto.getFurnitureName());
				addtocart.setFurnitureMaterialType(addtocartdto.getFurnitureMaterialType());
				addtocart.setFurnitureCount(addtocartdto.getFurnitureCount());
				addtoCartRepository.save(addtocart);
				responsedto.setMessage("Add To Cart");
				responsedto.setStatus(200);
				return responsedto;
			}
			else {
				responsedto.setMessage("Item does n't added to cart");
				responsedto.setStatus(204);
				if(addtocartdto.getFurnitureCount()<=0 && addtoCartRepository.existsById(addtocartdto.getFurnitureId())) {
					addtoCartRepository.deleteById(addtocartdto.getFurnitureId());
				}
				//System.out.print(addtocartdto.getFurnitureCount());
				return responsedto;

			}
			
			
		}
		catch(Exception e) {
			throw e;
		}
	//	return responsedto;
		return responsedto;
	}

	@Override
	public AddtoCartDto getAddtoCartItemsDetails() {
		// TODO Auto-generated method stub
		
		return null;
	}

}
