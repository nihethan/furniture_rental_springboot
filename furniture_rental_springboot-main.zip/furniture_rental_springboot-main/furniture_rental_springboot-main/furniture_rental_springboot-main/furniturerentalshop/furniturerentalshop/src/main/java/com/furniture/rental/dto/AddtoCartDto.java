package com.furniture.rental.dto;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class AddtoCartDto {
     private String furnitureId;
     private String furnitureMaterialType;
     private String furnitureName;
 
 	private int furnitureCount;
     
}
