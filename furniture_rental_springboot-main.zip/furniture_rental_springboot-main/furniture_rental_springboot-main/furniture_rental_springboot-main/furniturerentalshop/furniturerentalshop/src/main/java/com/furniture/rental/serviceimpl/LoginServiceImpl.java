package com.furniture.rental.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.furniture.rental.dao.LoginRepository;
import com.furniture.rental.dto.CustomerLoginDto;
import com.furniture.rental.dto.ResponseDto;
import com.furniture.rental.entity.LoginEntity;
import com.furniture.rental.service.LoginService;

import lombok.Data;


@Service
@Data
public class LoginServiceImpl implements LoginService{
  
	private final LoginRepository loginRepository;
	
	@Override
	public ResponseDto createLoginDetails(CustomerLoginDto customerDto) {
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
		try {
			LoginEntity login=new LoginEntity();
		if(customerDto.getUserName()!=null) {
			Optional<LoginEntity> option=loginRepository.findById(customerDto.getUserName());
			if(option.isPresent()) {
				login=option.get();
			//	login.setUserName(customerDto.getUserName());
				login.setPassword(customerDto.getPassword());
			}}
			else {
				login.setPassword(customerDto.getPassword());
			}
		loginRepository.save(login);
		response.setMessage("SuccesFully Added");
		response.setStatus(200);
		}
		
		catch(Exception e) {
			response.setMessage("Not added");
			throw e;
		}
		
		return response;
	}

//	@Override
//	public List<CustomerLoginDto> getLoginDetails() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public List<CustomerLoginDto> getLoginDetails() {
		//List<CustomerEntity> getdetail=loginRepository.getalldetail("")
	try {
		//CustomerLoginDto customer =new CustomerLoginDto();
		List<LoginEntity> studentList = loginRepository.findAll();

		List<CustomerLoginDto> dtoList = new ArrayList<CustomerLoginDto>();

		studentList.forEach(details -> {

			CustomerLoginDto dto = new CustomerLoginDto();
			
			dto.setUserName(details.getUserName());
			dto.setPassword(details.getPassword());
			dtoList.add(dto);

		});

		return dtoList;
		}
		catch(Exception e) {
			throw e;
		}

	}

	@Override
	public ResponseDto deleteLoginData(String userName) {
		// TODO Auto-generated method stub
		
			ResponseDto response = new ResponseDto();

			try {

				if (loginRepository.existsById(userName)) {
					loginRepository.deleteById(userName);
					response.setMessage("DELETE SUCCESFULLY");
					return response;
				}

				response.setMessage("STUDENT ID NOT FOUND");

			} catch (Exception e) {
				response.setMessage("FAILED");
				response.setStatus(500);
				throw e;
			}

			return response;

	}
	
@Override
public CustomerLoginDto getCustomerDetailsById(String userName) {
		// TODO Auto-generated method stub
         
		CustomerLoginDto logindto = new CustomerLoginDto();
		Optional<LoginEntity> customerOpt = loginRepository.findById(userName);
		if (!customerOpt.isEmpty()) {
		LoginEntity customer = customerOpt.get();
         logindto.setUserName(customer.getUserName());
         logindto.setPassword(customer.getPassword());
		}
		return logindto;
	
	}
	
	
	
	
    
}
