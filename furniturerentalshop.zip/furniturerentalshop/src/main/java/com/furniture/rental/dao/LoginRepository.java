package com.furniture.rental.dao;

public class LoginRepository {

}
