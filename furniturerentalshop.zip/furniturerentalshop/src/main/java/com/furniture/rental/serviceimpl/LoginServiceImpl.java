package com.furniture.rental.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.furniture.rental.dao.LoginRepository;
import com.furniture.rental.dto.CustomerLoginDto;
import com.furniture.rental.dto.ResponseDto;
import com.furniture.rental.entity.LoginEntity;
import com.furniture.rental.service.LoginService;

import lombok.Data;


@Service
@Data
public class LoginServiceImpl implements LoginService{
  
	private final LoginRepository loginRepository;
	
	@Override
	public ResponseDto createLoginDetails(CustomerLoginDto customerDto) {
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
		try {
			LoginEntity login=new LoginEntity();
		if(customerDto.getUserName()!=null) {
			Optional<LoginEntity> option=loginRepository.findById(customerDto.getUserName());
			if(option.isPresent()) {
				login=option.get();
			//	login.setUserName(customerDto.getUserName());
				login.setPassword(customerDto.getPassword());
			}}
			else {
				login.setPassword(customerDto.getPassword());
			}
		loginRepository.save(login);
		response.setMessage("SuccesFully Added");
		response.setStatus(200);
		}
		
		catch(Exception e) {
			response.setMessage("Not added");
			throw e;
		}
		
		return response;
	}

	@Override
	public List<CustomerLoginDto> getLoginDetails() {
		//List<CustomerEntity> getdetail=loginRepository.getalldetail("")
		try {
			//CustomerLoginDto customer =new CustomerLoginDto();
			List<LoginEntity> customer=s
			List<LoginEntity> dtoList=new ArrayList<LoginEntity>();
			
		}
		catch(Exception e) {
			throw e;
		}
		return null;

	}
	
	
    
}
