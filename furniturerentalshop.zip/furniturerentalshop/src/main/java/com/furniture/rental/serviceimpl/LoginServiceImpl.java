package com.furniture.rental.serviceimpl;

import org.springframework.stereotype.Service;

import com.furniture.rental.dto.CustomerLoginDto;
import com.furniture.rental.dto.ResponseDto;
import com.furniture.rental.service.LoginService;


@Service
public class LoginServiceImpl implements LoginService{

	@Override
	public ResponseDto createLoginDetails(CustomerLoginDto customerDto) {
		// TODO Auto-generated method stub
		ResponseDto response=new ResponseDto();
		try {
			
		}
		catch(Exception e) {
			throw e;
		}
		
		return response;
	}
    
}
