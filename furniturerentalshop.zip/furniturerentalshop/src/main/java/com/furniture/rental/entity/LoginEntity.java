package com.furniture.rental.entity;

@Entity
@Table(name="")
public class LoginEntity {
	
	private String userName;
	private String password;
	
	@Id
	@Table(name="logindetails")
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
