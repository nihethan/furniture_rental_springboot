package com.furniture.rental.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CustomerLoginDto {
	
	private String userName;
	private String password;
	
	public CustomerLoginDto(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	
	public CustomerLoginDto() {
		
	}
     
     
}
