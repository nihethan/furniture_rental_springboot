	package com.furniture.rental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FurniturerentalshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(FurniturerentalshopApplication.class, args);
	}

}
