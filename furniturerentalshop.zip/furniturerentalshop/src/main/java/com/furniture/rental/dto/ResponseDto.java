package com.furniture.rental.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ResponseDto {
	private String message;
	
	private int status;
	public ResponseDto(String message, int status) {
		super();
		this.message = message;
		this.status = status;
	}
	
	public ResponseDto() {
		
	}
	

	@Override
	public String toString() {
		return "ResponseDto [message=" + message + ", statusCode=" + status + "]";
	}

}
