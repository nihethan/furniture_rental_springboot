package com.furniture.rental.service;

import org.springframework.stereotype.Service;

import com.furniture.rental.dto.CustomerLoginDto;
import com.furniture.rental.dto.ResponseDto;
@Service
public interface LoginService {

	ResponseDto createLoginDetails(CustomerLoginDto customerDto);


}
